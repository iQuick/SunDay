package tk.woppo.sunday.domain;

import org.xml.sax.helpers.DefaultHandler;

/**
 * Created by Ho on 2014/6/29.
 */
public class BaseSaxParseHandler extends DefaultHandler {

    protected final static String TAG = "SaxParseHandler";
}

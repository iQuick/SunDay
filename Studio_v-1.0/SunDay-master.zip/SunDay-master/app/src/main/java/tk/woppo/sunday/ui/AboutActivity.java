package tk.woppo.sunday.ui;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.EActivity;

import tk.woppo.sunday.R;
import tk.woppo.sunday.widget.swipeback.SwipeBackActivity;

/**
 * Created by Ho on 2014/7/10.
 */
@EActivity(R.layout.activity_about)
public class AboutActivity extends SwipeBackActivity {

    @AfterViews
    void initActivity() {

    }
}
